/* =========================================================================
   SWAMI VIVEKANANDA SANGHA — SITE DATA & LOGIC
   =========================================================================
   Everything you need to update EVERY YEAR lives in the SITE_DATA object
   below. You do not need to touch index.html or style.css to:
     - add a new year's photos to the gallery
     - add, remove, or edit a committee member
     - change the address, map, Instagram handle, or contact details

   After editing this file, just save it and refresh the page.
   ========================================================================= */

const SITE_DATA = {

  /* -----------------------------------------------------------------------
     GALLERY — one entry per year, newest first. Pre-filled for every year
     from 2010 (founding year) to 2025, in serial order.

     "images" is a list of { src, caption }. Replace each placeholder src
     with your own file, e.g. "images/2025-1.jpg", once you add real photos
     to the /images folder. An empty images array is fine — that year will
     show a "photos coming soon" placeholder instead of breaking.

     ---- TO ADD A NEW YEAR (e.g. 2026) ----
     Add a new object at the very TOP of this array (newest year first):
     {
       year: 2026,
       images: [
         { src: "images/2026-1.jpg", caption: "Describe the photo" },
         { src: "images/2026-2.jpg", caption: "Describe another photo" },
       ],
     },

     ---- TO ADD MORE PHOTOS TO AN EXISTING YEAR ----
     Find that year's object below and add more { src, caption } entries
     to its "images" array.
     ----------------------------------------------------------------------- */
  gallery: [
    { year: 2025, images: [
      { src: "images/2025-1.jpg", caption: "Ma Durga, Panchami decoration" },
      { src: "images/2025-2.jpg", caption: "Sandhi Puja, 2025" },
      { src: "images/2025-3.jpg", caption: "Community bhog distribution" },
    ]},
    { year: 2024, images: [
      { src: "images/2024-1.jpg", caption: "Idol unveiling, Shashthi" },
      { src: "images/2024-2.jpg", caption: "Cultural evening, Ashtami" },
    ]},
    { year: 2023, images: [
      { src: "images/2023-1.jpg", caption: "Dhak and dhunuchi naach" },
    ]},
    { year: 2022, images: [
      { src: "images/2022-1.jpg", caption: "Sindoor khela, Dashami" },
    ]},
    { year: 2021, images: [
      { src: "images/2021-1.jpg", caption: "Anjali, Ashtami morning" },
    ]},
    { year: 2020, images: [
      { src: "images/2020-1.jpg", caption: "Puja during the pandemic year" },
    ]},
    { year: 2019, images: [] },
    { year: 2018, images: [] },
    { year: 2017, images: [] },
    { year: 2016, images: [] },
    { year: 2015, images: [] },
    { year: 2014, images: [] },
    { year: 2013, images: [] },
    { year: 2012, images: [] },
    { year: 2011, images: [] },
    { year: 2010, images: [
      { src: "images/2010-1.jpg", caption: "The Sangha's very first Durga Puja" },
    ]},
    // ---- ADD NEW YEARS ABOVE THE 2025 ENTRY AT THE TOP, NOT HERE ----
  ],

  /* -----------------------------------------------------------------------
     COMMITTEE — add or remove members freely. "title" can be any role:
     President, Vice President, Secretary, Joint Secretary, Treasurer,
     Cultural Head, Member, etc.
     ----------------------------------------------------------------------- */
  committee: [
    { name: "Amit Bhattacharya", title: "President", photo: "images/committee/amit.jpg" },
    { name: "Sudeshna Roy", title: "Vice President", photo: "images/committee/sudeshna.jpg" },
    { name: "Rajib Das", title: "General Secretary", photo: "images/committee/rajib.jpg" },
    { name: "Priya Sengupta", title: "Joint Secretary", photo: "images/committee/priya.jpg" },
    { name: "Sanjoy Ghosh", title: "Treasurer", photo: "images/committee/sanjoy.jpg" },
    { name: "Mou Chakraborty", title: "Cultural Secretary", photo: "images/committee/mou.jpg" },
    // ---- ADD NEW MEMBERS HERE ----
    // { name: "Full Name", title: "Role Title", photo: "images/committee/filename.jpg" },
  ],

  /* -----------------------------------------------------------------------
     LOCATION — paste your real Google Maps embed link and directions link.
     To get an embed link: open Google Maps -> Share -> Embed a map -> copy
     the URL inside the src="..." of the given <iframe> tag.
     To get a directions link: Share -> Copy link.
     ----------------------------------------------------------------------- */
  location: {
    address: "Swami Vivekananda Sangha Puja Pandal, Netaji Road, Kolkata, West Bengal 700001",
    mapEmbedUrl: "https://www.google.com/maps?q=Kolkata&output=embed",
    directionsUrl: "https://maps.google.com/?q=Swami+Vivekananda+Sangha+Kolkata",
  },

  /* -----------------------------------------------------------------------
     SOCIAL + CONTACT
     ----------------------------------------------------------------------- */
  social: {
    instagramUrl: "https://instagram.com/your_sangha_handle",
    instagramHandle: "@your_sangha_handle",
  },

  contact: {
    phone: "+91 90000 00000",
    email: "contact@swamivivekanandasangha.org",
    address: "Netaji Road, Kolkata, West Bengal 700001",
  },
};

/* =========================================================================
   RENDERING — you shouldn't need to edit below this line.
   ========================================================================= */

document.addEventListener("DOMContentLoaded", () => {
  renderGallery();
  renderCommittee();
  renderLocationAndContact();
  setupNav();
  setupLightbox();
  setupContactForm();
  document.getElementById("footerYear").textContent = new Date().getFullYear();
});

/* ---- Gallery accordion ---- */
function renderGallery() {
  const wrap = document.getElementById("yearAccordion");
  wrap.innerHTML = "";

  SITE_DATA.gallery.forEach((yearEntry, index) => {
    const card = document.createElement("article");
    card.className = "year-card";
    card.dataset.open = index === 0 ? "true" : "false"; // most recent year starts open

    const photoCount = yearEntry.images.length;

    const toggle = document.createElement("button");
    toggle.className = "year-toggle";
    toggle.setAttribute("aria-expanded", card.dataset.open);
    toggle.innerHTML = `
      <span>${yearEntry.year}
        <span class="year-count">${photoCount ? `${photoCount} photo${photoCount === 1 ? "" : "s"}` : "photos coming soon"}</span>
      </span>
      <span class="chevron" aria-hidden="true">&#9662;</span>
    `;
    toggle.addEventListener("click", () => {
      const isOpen = card.dataset.open === "true";
      card.dataset.open = isOpen ? "false" : "true";
      toggle.setAttribute("aria-expanded", String(!isOpen));
    });

    const photoGrid = document.createElement("div");
    photoGrid.className = "year-photos";

    if (photoCount === 0) {
      photoGrid.innerHTML = `<p class="year-empty">No photos added for ${yearEntry.year} yet — add some in the "gallery" list in script.js.</p>`;
    }

    yearEntry.images.forEach((img) => {
      const btn = document.createElement("button");
      btn.setAttribute("aria-label", `Open photo: ${img.caption}`);
      btn.innerHTML = `<img src="${img.src}" alt="${img.caption}" loading="lazy"
        onerror="this.closest('button').style.display='none'">`;
      btn.addEventListener("click", () => openLightbox(img.src, `${yearEntry.year} — ${img.caption}`));
      photoGrid.appendChild(btn);
    });

    card.appendChild(toggle);
    card.appendChild(photoGrid);
    wrap.appendChild(card);
  });
}

/* ---- Committee grid ---- */
function renderCommittee() {
  const grid = document.getElementById("committeeGrid");
  grid.innerHTML = "";

  SITE_DATA.committee.forEach((member) => {
    const initials = member.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
    const card = document.createElement("div");
    card.className = "member-card";
    card.innerHTML = `
      <img class="member-photo" src="${member.photo}" alt="${member.name}" loading="lazy"
        onerror="this.outerHTML='<span class=&quot;member-photo member-initials&quot;>${initials}</span>'">
      <p class="member-name">${member.name}</p>
      <span class="member-title">${member.title}</span>
    `;
    grid.appendChild(card);
  });
}

/* ---- Location + contact ---- */
function renderLocationAndContact() {
  const { location, social, contact } = SITE_DATA;

  document.getElementById("locationAddress").textContent = location.address;
  document.getElementById("mapFrame").src = location.mapEmbedUrl;
  document.getElementById("directionsBtn").href = location.directionsUrl;

  document.getElementById("instaLink").href = social.instagramUrl;
  document.getElementById("instaHandle").textContent = `Follow us — ${social.instagramHandle}`;

  const contactList = document.getElementById("contactList");
  contactList.innerHTML = `
    <li>Phone: <a href="tel:${contact.phone.replace(/\s+/g, "")}">${contact.phone}</a></li>
    <li>Email: <a href="mailto:${contact.email}">${contact.email}</a></li>
    <li>Address: ${contact.address}</li>
  `;
}

/* ---- Mobile nav toggle ---- */
function setupNav() {
  const toggle = document.getElementById("navToggle");
  const nav = document.getElementById("mainNav");

  toggle.addEventListener("click", () => {
    const isOpen = nav.dataset.open === "true";
    nav.dataset.open = String(!isOpen);
    toggle.setAttribute("aria-expanded", String(!isOpen));
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => { nav.dataset.open = "false"; });
  });
}

/* ---- Lightbox ---- */
function setupLightbox() {
  const lightbox = document.getElementById("lightbox");
  document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
  lightbox.addEventListener("click", (e) => {
    if (e.target === lightbox) closeLightbox();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeLightbox();
  });
}

function openLightbox(src, caption) {
  const lightbox = document.getElementById("lightbox");
  document.getElementById("lightboxImg").src = src;
  document.getElementById("lightboxImg").alt = caption;
  document.getElementById("lightboxCaption").textContent = caption;
  lightbox.dataset.visible = "true";
}

function closeLightbox() {
  document.getElementById("lightbox").dataset.visible = "false";
}

/* ---- Contact form (front-end only — no backend wired up) ---- */
function setupContactForm() {
  const form = document.getElementById("contactForm");
  const note = document.getElementById("formNote");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    // NOTE: this only shows a confirmation message. To actually receive
    // messages, connect this form to a service like Formspree, Netlify
    // Forms, or your own backend endpoint.
    note.textContent = "Thank you — your message has been noted. We'll get back to you soon.";
    form.reset();
  });
}
